using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DevAtanIRC
{
    public delegate void OpenEvent(object sender, EventArgs e);
    public delegate void ClosedEvent(object sender, EventArgs e);
    public interface IPlugin
    {  
        event OpenEvent Opened;
        event ClosedEvent Closed;
    }
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault( false );
			Application.Run(new Form1());
		}
	}
}